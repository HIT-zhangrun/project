#ifndef __DELAY_H__
#define __DELAY_H__

#include "intrins.h"
#define uint_8 	    unsigned char
#define uint_16 		unsigned int

void delay1ms(int t);
void Delay20us();

#endif
